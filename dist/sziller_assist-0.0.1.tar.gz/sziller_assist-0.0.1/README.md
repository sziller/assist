# assist
Collection of general helpers, small, mostly standalone functions
